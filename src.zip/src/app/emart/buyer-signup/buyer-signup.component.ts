import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-buyer-signup',
  templateUrl: './buyer-signup.component.html',
  styleUrls: ['./buyer-signup.component.css']
})
export class BuyerSignupComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
