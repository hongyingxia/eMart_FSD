export interface Buyer{
    id: number,
    username: string,
    password: string,
    email: string,
    mobile: number,
    date: string
}