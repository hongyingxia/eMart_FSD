import { Item } from './item';

export interface Cart{
    cartItems: Item[]
}