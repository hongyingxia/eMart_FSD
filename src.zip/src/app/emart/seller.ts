export interface Seller{
    id: number,
    username: string,
    password: string,
    company: string,
    brief: string,
    gst: number,
    address: string,
    email: string,
    website: string,
    contact: number
}